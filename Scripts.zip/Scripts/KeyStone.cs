﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class KeyStone : MonoBehaviour
{
    public int orderStep;
    public StoneManager stoneManager;
    Vector3 firstPosition;
    // Start is called before the first frame update
    void Start()
    {
        firstPosition = transform.position;
        stoneManager = GameObject.Find("StoneManager").GetComponent<StoneManager>();
    }

    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("evet girdim");
        if (other.gameObject.CompareTag("Player"))
        {
            StonePushed();
            if (orderStep ==0)
            {
                Debug.Log("Öldün aq çık");
                stoneManager.ResetAllPos();
                stoneManager.ResetThePlayer();
            }
        }
    }


    public void StonePushed()
    {
       
        transform.position = new Vector3(transform.position.x, transform.position.y - .08f, transform.position.z);

    }

    public void ResetPosition()
    {
        transform.position = firstPosition;
    }
}
