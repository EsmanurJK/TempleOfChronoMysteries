using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoneManager : MonoBehaviour
{
    public KeyStone[] stones;
    public GameObject player;
    public GameObject startPoint;

    public void ResetAllPos()
    {
        foreach (var item in stones)
        {
            item.ResetPosition();

        }
    }

    public void ResetThePlayer()
    {
        player.transform.position = new Vector3(
            startPoint.transform.position.x,
            startPoint.transform.position.y,
            startPoint.transform.position.z
            );
    }
    

    private void Start()
    {
        player = GameObject.FindWithTag("Player");
    }


}
