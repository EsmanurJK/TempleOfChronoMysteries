﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float jumpForce;
    float mouseX;

    private bool isGrounded = true;
    private bool isRun;
    
    private bool onMovingPlatform = false;
    public GameObject movingplatform;
    public GameObject isPuzzleActive;

    private Rigidbody rb;
    private Animator animator;
    private void Awake()
    {
        Time.timeScale = 1f;
        rb = GetComponent<Rigidbody>();
        animator = GetComponent<Animator>();
    }
    void Start()
    {
       
    }
    private void FixedUpdate()
    {
        if ((transform.position.y < -5f))
        {
            transform.position = new Vector3(-40, 3, 100);
        }
        {
            
        }
        if (onMovingPlatform)
        {
            Vector3 newPosition = transform.position;
            newPosition.z = movingplatform.transform.position.z;
            transform.position = newPosition;
        }
        animator.SetBool("Jumped", !isGrounded);
        if (Input.GetKey(KeyCode.LeftShift))
        {
            moveSpeed = 10f;
            isRun = true;
        }
        else
        {
            isRun = false;
            moveSpeed = 5f;
        }
        animator.SetBool("isRun", isRun);

        if (!isPuzzleActive.active) 
        {
            mouseX = Input.GetAxis("Mouse X") * Time.deltaTime * 800f;
            transform.Rotate(Vector3.up * mouseX);
        }

        

        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");
        if (vertical < 0)
        {
            vertical = 0;
        }
        Vector3 moveDirection = (transform.right * horizontal + transform.forward * vertical).normalized;

        bool isWalking = moveDirection.magnitude > 0;
        animator.SetBool("isWalking", isWalking);

        transform.Translate(moveDirection * moveSpeed * Time.deltaTime, Space.World);

        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            onMovingPlatform = false;
            isGrounded = false;
            rb.velocity = jumpForce * Vector3.up;
        }

       
    }

    void Update()
    {

    }
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "Ground")
        {
            isGrounded=true;
        }
        
    }

    private void OnCollisionStay(Collision collision)
    {
        if(collision.gameObject.tag == "MovingPlatform")
        {
            isGrounded = true;
            onMovingPlatform = true;
            movingplatform = collision.gameObject;
        }
    }
    private void OnCollisionExit(Collision collision)
    {
        if(collision.gameObject.tag == "MovingPlatform")
        {
            onMovingPlatform = false;
            movingplatform = collision.gameObject;
        }
    }



}
