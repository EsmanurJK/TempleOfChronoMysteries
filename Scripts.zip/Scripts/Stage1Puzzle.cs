using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stage1Puzzle : MonoBehaviour
{
    public GameObject puzzleCanvas;


    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.CompareTag("Player"))
        {
            puzzleCanvas.SetActive(true);
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            puzzleCanvas.SetActive(false);
        }
    }
}
