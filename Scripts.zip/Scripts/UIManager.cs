using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
public class UIManager : MonoBehaviour
{
    private TMPro.TMP_Text pro;
    private TMPro.TMP_Text pro2;

    public TextMeshProUGUI gamename;
    public TextMeshProUGUI gamename2;


    public GameObject button1;
    public GameObject button2;
    public GameObject button3;

    public GameObject info_panel;
    private bool infoopen = false;
    // Start is called before the first frame update
    private void Awake()
    {
        Time.timeScale = 1.0f;
    }
    void Start()
    {
        pro = gamename.GetComponent<TMP_Text>();
        pro.alpha = 0f;

        pro2 =gamename2.GetComponent<TMP_Text>(); pro2.alpha = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        if(pro.alpha < 1.0f)
        {
            pro.alpha += Time.deltaTime / 4;
            if(pro.alpha >= 1.0f) 
            {
                StartCoroutine(OneSecond());
            }
        }
        if(pro2.alpha < 1.0f)
        {
            pro2.alpha += Time.deltaTime / 4;
            if (pro2.alpha >= 1.0f)
            {
                StartCoroutine(OneSecond());
            }
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            
            if (infoopen)
            {
                info_panel.SetActive(false);
            }
        }
    }

    IEnumerator OneSecond()
    {
        yield return new WaitForSecondsRealtime(5);
        Destroy(gamename);
        Destroy(gamename2 );
        button1.SetActive(true);
        button2.SetActive(true);
        button3.SetActive(true);

    }

    public void Play()
    {
        SceneManager.LoadScene(1);
    }

    public void Quit()
    {
        Application.Quit();

    }
    public void Info()
    {
        info_panel.SetActive(true);
        infoopen = true;
    }
}
