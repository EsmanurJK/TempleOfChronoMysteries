using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UIElements;
using UnityEngine.UI;
using UnityEditor;

public class ThePiece : MonoBehaviour, IDragHandler, IDropHandler
{
    private RectTransform rectTransform;
    private Vector2 firstPosition;
    public Canvas canvas;
    public RectTransform []slotPositions;
    public int puzzleOrder;
    public TheSlotsManager slotsManager;

    public void OnDrag(PointerEventData eventData)
    {
        rectTransform.anchoredPosition += eventData.delta / canvas.scaleFactor;
    }


    public void OnDrop(PointerEventData eventData)
    {
        bool worked = false;
        foreach (var position in slotPositions)
        {

            float distanceBetween = Vector2.Distance(rectTransform.anchoredPosition, position.anchoredPosition);

            if(distanceBetween < 50f && !worked)
            {
                int slotOrder = position.gameObject.GetComponent<TheSlots>().puzzleOrder;
                
                if (slotsManager.CheckingSlotStatus(slotOrder))
                {
                    Debug.Log(slotOrder);
                    rectTransform.position = position.position;
                    slotsManager.CheckingPuzzleStatus(puzzleOrder == slotOrder);
                    worked = true;
                }

                
            }
        }
        if (!worked)
            RestartPos();

    }


    public void RestartPos()
    {
        rectTransform.anchoredPosition = firstPosition;
    }


    private void Start()
    {
        rectTransform = GetComponent<RectTransform>();
        firstPosition = rectTransform.anchoredPosition;
    }
    
}
