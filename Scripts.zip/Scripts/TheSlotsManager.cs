using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TheSlotsManager : MonoBehaviour
{
    public ThePiecesManager piecesManager;
    public GameObject failedScrene;
    public GameObject completedScene;
    public GameObject[] doors;
    public GameObject cancas;

    public List<int> filledSlots = new List<int>();


    int trueCount;
    int falseCount;

    private void Start()
    {
    }
    private void Update()
    {
    }
    public void CheckingPuzzleStatus(bool get)
    {
        if(get)
            trueCount++;
        else
            falseCount++;

        if (trueCount == 5)
            CompletedPuzzle();
        else if(trueCount + falseCount == 5)
            RestartPuzzle();
    }



    public void CompletedPuzzle()
    {
        Debug.Log("Puzzle completed");
        completedScene.SetActive(true);
        Invoke("CloseTheCanvas",1f);
        OpenTheDoors();
    }

    public void CloseTheCanvas()
    {
        cancas.gameObject.SetActive(false);
    }


    public void RestartPuzzle()
    {
        Debug.Log("Puzzle Restarted");
        piecesManager.RestartAll();
        failedScrene.SetActive(true);
        trueCount = 0;
        falseCount = 0;
    }

    public void CloseFailedScrene()
    {
        failedScrene.SetActive(false);

    }

    public bool CheckingSlotStatus(int slot)
    {
        foreach (var item in filledSlots)
        {
            if (item == slot)
                return false;
        }
        filledSlots.Add(slot);
        return true;
    }

    public void ResetAllFilledSlots()
    {
        filledSlots.Clear();
    }

    public void OpenTheDoors()
    {
        foreach (var item in doors)
        {
            Destroy(item);
        }
    }
}
