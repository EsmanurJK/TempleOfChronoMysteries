﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CountDown : MonoBehaviour
{
    public float timeRemaining = 180f; 
    public bool timerIsRunning = false;
    public TMP_Text timeText;
    public GameObject gameoverpanel;
    public bool win;
    bool start = false;
    public ExitPoint end;

    // Start is called before the first frame update
    void Start()
    {
        end = GameObject.Find("EndPoint").GetComponent<ExitPoint>();
        timerIsRunning = true;
        StartCoroutine(Wait());
    }

    // Update is called once per frame
    void Update()
    {
        win = end.win;
        if(!win && start) {
            if (timerIsRunning)
            {
                if (timeRemaining > 0)
                {
                    timeRemaining -= Time.deltaTime;
                    DisplayTime(timeRemaining);
                }
                else
                {
                    Debug.Log("Time has run out!");
                    timeRemaining = 0;
                    timerIsRunning = false;
                    Time.timeScale = 0f;
                    gameoverpanel.SetActive(true);
                }
            }
        }
        
    }
    void DisplayTime(float timeToDisplay)
    {
        timeToDisplay += 1;

        float minutes = Mathf.FloorToInt(timeToDisplay / 60);
        float seconds = Mathf.FloorToInt(timeToDisplay % 60);

        timeText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }
    IEnumerator Wait()
    {
        yield return new WaitForSeconds(11);
        start = true;
    }
}
