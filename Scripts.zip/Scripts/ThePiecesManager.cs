using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using Unity.VisualScripting;
using UnityEngine;

public class ThePiecesManager : MonoBehaviour
{
    int id;
    public GameObject popupMessage;
    public GameObject []pieces;
    public TheSlotsManager slotManager;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void RestartAll()
    {
        foreach (var item in pieces)
        {
            item.GetComponent<ThePiece>().RestartPos();
        }
        slotManager.ResetAllFilledSlots();
        
    }

    public void AddaPiece()
    {
        OpenPopup();
        pieces[id].gameObject.SetActive(true);
        if(id<pieces.Length-1)
        id++;
    }

    public void OpenPopup()
    {
        popupMessage.SetActive(true);
        Invoke("ClosePopup",1f);
    }

    public void ClosePopup()
    {
        popupMessage.SetActive(false);
    }
}
