using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameSceneUI : MonoBehaviour
{
    public GameObject panel;
    public GameObject infopanel;
    public GameObject winPanel;

    public bool infopanelopen;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.P))
        {
            Time.timeScale = 0f;
            panel.SetActive(true);

        }
        if (Input.GetKeyDown(KeyCode.Escape))
        {

            if (infopanelopen)
            {
                infopanel.SetActive(false);
                panel.SetActive(true);
                infopanelopen = false;
            }
            else
            {
                Time.timeScale = 1f;
                panel.SetActive(false);
            }
           
        }
    }
    public void Continue()
    {
        panel.SetActive(false);
        Time.timeScale = 1f;
    }
    public void Restart()
    {
        SceneManager.LoadScene(1);
        winPanel.SetActive(false);
    }
    public void Info()
    {
        infopanelopen = true;
        panel.SetActive(false);
        infopanel.SetActive(true);
    }
    public void MainMenu()
    {
        SceneManager.LoadScene(0);

    }
    public void Quit()
    {
        Application.Quit();
    }
}
