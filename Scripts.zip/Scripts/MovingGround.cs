using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingGround : MonoBehaviour
{
    public float speed = 2.0f;  
    public float zMin = 97.0f;  
    public float zMax = 105.0f;
    bool speeder = false;
    bool slower = false;
    public bool movingForward = true;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Alpha1) && !slower)
        {
            StartCoroutine(TimeSpeeder());
        }
        if (Input.GetKeyDown(KeyCode.Alpha2) && !speeder)
        {
            StartCoroutine(TimeSlower());
        }
        Vector3 currentPosition = transform.position;
        if (movingForward)
        {
            currentPosition.z += speed * Time.deltaTime;

            if (currentPosition.z >= zMax)
            {
                currentPosition.z = zMax; 
                movingForward = false; 
            }
        }
        else 
        {
           
            currentPosition.z -= speed * Time.deltaTime;

            
            if (currentPosition.z <= zMin)
            {
                currentPosition.z = zMin; 
                movingForward = true; 
            }
        }

        
        transform.position = currentPosition;

    }
    IEnumerator TimeSpeeder()
    {
        speeder = true;
        speed = 6f;
        yield return new WaitForSeconds(3f);
        speed = 2f;
        speeder = false;
    }

    IEnumerator TimeSlower()
    {
        slower = true;
        speed = 0.5f;
        yield return new WaitForSeconds(3f);
        speed = 2f;
        slower = false;
    }
}
